thisset = {'apple', 'banana', 'cherry'}
print('banana' not in thisset)