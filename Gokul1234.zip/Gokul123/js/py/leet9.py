x=10
if x<0:
    print(False)
else:
    a=str(x)
    b=a[::-1]
    print(b==a)