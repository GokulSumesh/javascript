class Student:
    def __init__(self, name, age, grade):
        self.name = name
        self.age = age
        self.grade = grade

    # Method to add a new student (simulated here as initializing a new object)
    def add_student(self, name, age, grade):
        self.name = name
        self.age = age
        self.grade = grade

    # Method to update student details
    def update_student(self, name=None, age=None, grade=None):
        if name is not None:
            self.name = name
        if age is not None:
            self.age = age
        if grade is not None:
            self.grade = grade

    # Method to modify specific attributes (more fine-grained control)
    def modify_student(self, attribute, value):
        if attribute == "name":
            self.name = value
        elif attribute == "age":
            self.age = value
        elif attribute == "grade":
            self.grade = value
        else:
            print(f"Invalid attribute: {attribute}")

    # Method to display student details
    def display_student(self):
        print(f"Name: {self.name}")
        print(f"Age: {self.age}")
        print(f"Grade: {self.grade}")

# Example usage:

# Create a new student instance
student1 = Student("John Doe", 15, "10th Grade")

# Display the student details
student1.display_student()

# Update student's age and grade
student1.update_student(age=16, grade="11th Grade")
print("\nUpdated Details:")
student1.display_student()

# Modify the student's name
