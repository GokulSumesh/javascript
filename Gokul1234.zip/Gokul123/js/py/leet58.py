Input: s = "Hello World"
a=s.split()
print(len(a[-1]))