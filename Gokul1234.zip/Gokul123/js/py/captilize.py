# arr="The biggest risk is not taking any risk."
# a=arr.replace('r','R')
# print(a)

# arr="The biggest risk is not taking any risk."
# a=arr.split()
# for i in range(len(a)):
#     if a[i].startswith("r"):
#         a[i]=a[i].capitalize()
#         b=" ".join(a)
# print(b)



# arr="The biggest risk is not taking any risk."
# a=arr.split()
# for i in range(len(a)):
#     if a[i].startswith("r"):
#         a[i]=a[i].upper()
#         b=" ".join(a)
# print(b)
        

arr="If you are waiting for the right time, it's now"
a=arr.split()
for i in range(len(a)):
    if a[i].startswith("t"):
        a[i]=a[i].upper()
        b=" ".join(a)
print(b)



# arr="If you are waiting for the right time, it's now"
# a=arr.split()
# for i in a[::-1]:
#     b=a[i].upper()
#     print(b)
#     break


# arr="If you are waiting for the right time, it's now"
# a=arr.split()[-1]
# b=a.upper()
# print(b)

        
    




