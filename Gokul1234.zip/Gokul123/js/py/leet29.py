a= 7
# b =-3
# result=a/b
# if result<0:
#     result=-result
#     print(s) 
# else:
# print(result)


a= 7
b =-3
if dividend == -2147483648 and divisor ==-1:
            return 2147483647
        result=dividend/divisor
        c=int(result)
        return c
