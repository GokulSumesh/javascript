# class calculator:
#     def add(self,a,b):
#         print(a+b)

#     def sub(self,a,b):
#         print(a-b)

#     def mul(self,a,b):
#         print(a*b)

#     def div(self,a,b):
#         print(a/b)

#     def mod(self,a,b):
#         print(a%b)

#     def exp(self,a,b):
#         print(a**b)
# a=calculator()
# a.add(10,20)
# a.sub(10,20)
# a.mul(10,20)
# a.div(10,20)
# a.mod(10,20)
# a.exp(10,20)



class user:
    l=[]
    def add(self,a):
        self.l.append(a)
    def delete(self,a): 
            self.l.remove(a)
        
    def update(self,a,b):
            c = self.l.index(a)
            self.l[c] = b
        
    def display(self):
        print(self.l)
        
a = user()
a.add("brand", "Ford")
a.add("model", "Mustang")
a.add("year", 1964)
a.delete("banana")
a.update("apple", "grape")
a.display()


