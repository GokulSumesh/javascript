# i = 1
# while i <= 10:
#   print(i)
#   i += 1



# a=50
# b=100
# while a<=b:
    
#     if a%8==0:
#         print(a)
        
#     a+=1



# a=20
# b=120
# c=0
# while a<=b:
#     if a%7==0:
#        c+=a
#     a+=1
# print(c)  



# a=int(input("Enter the Number: "))
# i=1
# while i<=a:
#     j=1
#     while j<=a:
#         print("*",end="")
#         j+=1
#     print()
#     i+=1



# a=int(input("Enter the Number: "))
# i=1

# while i<=a:
#     print(5*"*")
#     i+=1



# Triangle
# a=int(input("Enter the Number: "))
# i=1
# while i<=a:
#     j=1
#     while j<=i:
#         print("*",end="")
#         j+=1
#     print()
#     i+=1



# a=int(input("Enter the Number: "))
# i=1
# while i<=a:
#         print(i*"*")
#         i+=1



# a=int(input("Enter the Number: "))
# i=1
# m=1
# b=4

# while m<=a:    
#         print(" "*b+"*"*i) 
#         b-=1
#         m+=1 
#         i+=2




# a=int(input("Enter the Number: "))
# i=9
# m=1
# b=0

# while a>=m:    
#         print(" "*b+"*"*i) 
#         b+=1
#         m+=1 
#         i-=2


# a=int(input("Enter the Number: "))
# i=7
# m=1
# b=1
# c=1
# e=1
# d=4
# while e<=a:    
#         print(" "*d+"*"*c) 
#         d-=1
#         e+=1 
#         c+=2
# while a>=m:    
#         print(" "*b+"*"*i) 
#         b+=1
#         m+=1 
#         i-=2



# a=int(input("Enter the Number: "))
# c=1
# e=1
# d=4
# while e<=a:    
#         print(" "*d,c) 
#         d-=1
#         e+=1 
#         c+=2




# a=int(input("Enter the Number: "))
# i=1
# d=4
# while i<=a: 
#         j=1
#         while j<=i:
#                 print(j,end="")
                
#                 j+=1
#         k=i-1
#         while k>=1:
#                 print(k,end="")
#                 k-=1
#         print()
#         i+=1



# a=int(input("Enter the Number: "))
# i=1
# while i<=a: 
#         d=4
#         while d>=i:
#                 print("@",end="")
#                 d-=1
#         j=1
#         while j<=i:
#                 print(j,end="")
#                 j+=1
#         k=i-1
#         while k>=1:
#                 print(k,end="")
#                 k-=1
#         print()
#         i+=1



# a=int(input("Enter the Number: "))
# i=1
# while i<=a: 
#         print(" "*(a-i),end="")
#         j=1
#         while j<=i:
#                 print(j,end="")
#                 j+=1
#         k=i-1
#         while k>=1:
#                 print(k,end="")
#                 k-=1
#         print()
#         i+=1





# a=int(input("Enter the Number: "))
# i=1
# while i<=a: 
#         d=4
#         while d>=i:
#                 print(" ",end="")
#                 d-=1
#         k=i
#         while k>=1:
#                 print(k,end="")
#                 k-=1
#         j=2
#         while j<=i:
#                 print(j,end="")
#                 j+=1
        
        
#         print()
#         i+=1




# a = int(input("Enter the Number: "))
# i = a-1  
# while i >= 1: 
#     d = 4
#     while d >= i:  
#         print(" ", end="")
#         d -= 1

#     k = i
#     while k >= 1:  
#         print(k, end="")
#         k -= 1

#     j = 2
#     while j <= i: 
#         print(j, end="")
#         j += 1

#     print()
#     i -= 1  




a=int(input("Enter the Number: "))
i=1
while i<=a: 
        d=4
        while d>=i:
                print(" ",end="")
                d-=1
        k=i
        while k>=1:
                print(k,end="")
                k-=1
        j=2
        while j<=i:
                print(j,end="")
                j+=1
        
        
        print()
        i+=1
i=a-1
while i>=1: 
        d=4
        while d>=i:
                print(" ",end="")
                d-=1
        k=i
        while k>=1:
                print(k,end="")
                k-=1
        j=2
        while j<=i:
                print(j,end="")
                j+=1
        
        
        print()
        i-=1



                
















 


        
          













