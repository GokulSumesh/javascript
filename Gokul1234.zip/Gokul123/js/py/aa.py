class ListManager:
    def __init__(self):
        self.data_list = []

    def add(self, item):

        self.data_list.append(item)
        print(item)

    def delete(self, item):

        if item in self.data_list:
            self.data_list.remove(item)
            print(item)
        else:
            print(item)

    def update(self, old_item, new_item):

        if old_item in self.data_list:
            index = self.data_list.index(old_item)
            self.data_list[index] = new_item
            print({old_item},{new_item})
        else:
            print({old_item})

list_manager = ListManager()
list_manager.add("apple")
list_manager.add("banana")
list_manager.add("cherry")


list_manager.delete("banana")


list_manager.update("apple", "grape")



