package js.py;

public class a {

    public static void main(String[] args) {
        int r=5;
        for(int i =0 ; i<r;i++){

            for(int j =i ; j<r;j++){
                System.out.print("-");
            }

            for(int j =1 ; j<=i;j++){
                System.out.print("*"); 
            }
            
            System.out.println();
        }
    }
}