# arr =[1,2,3,8,6,8,10,7,6,14]
# arr.sort()
# print(arr)


# arr =[1,2,3,8,6,8,10,7,6,14]
# i=0
# temp=0
# while i<len(arr):
#     j=i+1
#     while j<len(arr):
#         if arr[i]>arr[j]:
#             temp=arr[i]
#             arr[i]=arr[j]
#             arr[j]=temp  
#         j+=1
#     i+=1
# print(arr[j])



# arr=[1,2,3,7,8,9]
# i=0
# j=len(arr)//2
# while i<j:
#     print(arr[i])
#     print(arr[i+j])
#     i+=1



# arr=[1,2,3,4,5,6,7,8,9,10]
# i=0
# j=i+1
# temp=0
# while i<len(arr):
#     if i<j:
#         temp=arr[i]
#         arr[i]=arr[j]
#         arr[j]=temp
#     j+=2
#     i+=2

# print(arr)

# a="The Biggest #risk is not #taking any risk."
# b=a.split()
# i=0
# while i<a.split:
#     i+=1
#     while j<
# print(b)
