a=int(input("Enter the Value"))
b=1
c=10
if a%2==0:
    while b<=10:
        print(b,"*",a,"=",b*a)
        b+=1
        
else:
    while c >= 1:
        print(c,"*",a,"=",c*a)
        c-=1