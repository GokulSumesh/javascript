# def welcome(name):
#     print("welcome to python functions ",name)


# welcome("veleswaran")

# def add(a,b):
#     print(a+b)



# def sub(a,b):
#     print(a-b)



# def mul(a,b):
#     print(a*b)



# def div(a,b):
#     print(a/b)



# def mod(a,b):
#     print(a%b)



# def exp(a,b):
#     print(a**b)


# add(-40,-700)

# name=["Gokul","Karan","Karthi","Kavin","Ravi","Ram","Raj","Nandha","Naveen","Sumesh"]
# def hello(name):
#     for i in range(len(name)):
#         print("Person",i+1,":",name[i])
# hello(name)



# a= {"brand": "Ford","model": "Mustang","year": 1964}

# def hello(a):
#         for i in (a.items()):
#                 print(i)
# hello(a)


# a= {"brand": "Ford","model": "Mustang","year": 1964}

# def hello(a):
#         for i in a:
#                 print(i,":",a[i])
# hello(a)

1 <= b and b<= 9 and a[b-1] not in['X','O']: